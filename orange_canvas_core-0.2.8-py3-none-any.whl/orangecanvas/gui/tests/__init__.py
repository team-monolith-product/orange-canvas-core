"""
Tests for gui toolkit

"""
